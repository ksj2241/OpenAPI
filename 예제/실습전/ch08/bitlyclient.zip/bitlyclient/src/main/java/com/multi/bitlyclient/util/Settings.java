package com.multi.bitlyclient.util;

public class Settings {
	public static final String CLIENT_ID = "";
	public static final String CLIENT_SECRET = "";
	public static final String AUTHORIZE_URL="https://bitly.com/oauth/authorize";
	public static final String ACCES_TOKEN_URL = "https://api-ssl.bitly.com/oauth/access_token";
	public static final String REDIRECT_URI = "http://jcornor.com:8000/callback";
	public static final String SHORTEN_API_URL = "https://api-ssl.bitly.com/v4/shorten";
}
