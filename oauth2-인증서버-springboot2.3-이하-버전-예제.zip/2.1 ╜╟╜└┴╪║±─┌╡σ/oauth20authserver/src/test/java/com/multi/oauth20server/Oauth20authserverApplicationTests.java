package com.multi.oauth20server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth20authserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
